// Background service worker for Rvised Chrome Extension
console.log('🔧 Rvised background script loaded');

// Production API endpoint
const PROD_API_BASE_URL = 'https://rvised.vercel.app';

async function fetchWithTimeout(url, options = {}, timeoutMs = 1500) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(id);
  }
}

async function resolveApiBaseUrl() {
  // 1) Allow explicit override via chrome.storage
  try {
    const stored = await chrome.storage?.sync?.get?.(['apiBaseOverride']);
    if (stored && stored.apiBaseOverride) {
      return stored.apiBaseOverride;
    }
  } catch (_) {}

  // 2) Prefer local dev if health endpoint responds
  const candidates = [
    'http://localhost:3000',
    'https://localhost:3000',
    PROD_API_BASE_URL,
  ];
  for (const base of candidates) {
    try {
      const res = await fetchWithTimeout(`${base}/api/health`, { method: 'GET' }, 1200);
      if (res.ok) return base;
    } catch (_) {}
  }
  return PROD_API_BASE_URL;
}

// Listen for extension installation
chrome.runtime.onInstalled.addListener(function(details) {
  console.log('📚 Rvised extension installed/updated');
  
  if (details.reason === 'install') {
    // Open welcome page on first install
    resolveApiBaseUrl().then((base) => {
      chrome.tabs.create({ url: `${base}?welcome=extension` });
    });
  }

  // Ensure a single context menu exists; remove all then create to avoid duplicate id error
  chrome.contextMenus.removeAll(() => {
    const _ = chrome.runtime.lastError; // ignore
    chrome.contextMenus.create({
      id: 'summarizeVideo',
      title: '📚 Summarize with Rvised',
      contexts: ['page'],
      documentUrlPatterns: ['https://www.youtube.com/watch*', 'https://www.youtube.com/shorts/*', 'https://www.youtube.com/embed/*']
    });
  });
});

// Also ensure menu exists on browser startup (service worker may restart)
chrome.runtime.onStartup?.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    const _ = chrome.runtime.lastError;
    chrome.contextMenus.create({
      id: 'summarizeVideo',
      title: '📚 Summarize with Rvised',
      contexts: ['page'],
      documentUrlPatterns: ['https://www.youtube.com/watch*', 'https://www.youtube.com/shorts/*', 'https://www.youtube.com/embed/*']
    });
  });
});

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  
  if (message.action === 'summarizeVideo') {
    handleVideoSummarization(message.data, sender, sendResponse);
    return true; // Keep the message channel open for async response
  }
  
  if (message.action === 'openDashboard') {
    resolveApiBaseUrl().then((base) => {
      chrome.tabs.create({ url: `${base}/dashboard` });
    });
    sendResponse({success: true});
  }
  
  if (message.action === 'getApiStatus') {
    checkApiStatus(sendResponse);
    return true; // Keep the message channel open for async response
  }
  if (message.action === 'fetchTranscriptServer') {
    resolveApiBaseUrl().then(async (base) => {
      try {
        const resp = await fetch(`${base}/api/transcript`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoUrl: message.videoUrl, videoId: message.videoId })
        });
        const json = await resp.json();
        sendResponse(json);
      } catch (e) {
        sendResponse({ success: false, error: e instanceof Error ? e.message : 'Failed' });
      }
    });
    return true;
  }
  if (message.action === 'getResolvedBase') {
    resolveApiBaseUrl().then((base) => sendResponse({ base })).catch(() => sendResponse({ base: PROD_API_BASE_URL }));
    return true;
  }
});

// Handle video summarization
async function handleVideoSummarization(data, sender, sendResponse) {
  try {
    console.log('🎬 Starting video summarization:', data.videoId);
    const BASE = await resolveApiBaseUrl();
    
    // Prefer resolved base (local if available), then try the rest
    let response = await fetch(`${BASE}/api/summarize`, {
      method: 'POST',
      body: JSON.stringify({
        videoUrl: data.url,
        settings: data.settings || {},
        extensionTranscript: data.transcript,
        extensionChapters: data.chapters
      })
    });
    
    // Try local dev HTTPS then HTTP if prod fails
    if (!response.ok) {
      try {
        response = await fetch(`https://localhost:3000/api/summarize`, {
          method: 'POST',
          body: JSON.stringify({
            videoUrl: data.url,
            settings: data.settings || {},
            extensionTranscript: data.transcript,
            extensionChapters: data.chapters
          })
        });
      } catch (_) {}
    }
    if (!response.ok) {
      try {
        response = await fetch(`http://localhost:3000/api/summarize`, {
          method: 'POST',
          body: JSON.stringify({
            videoUrl: data.url,
            settings: data.settings || {},
            extensionTranscript: data.transcript,
            extensionChapters: data.chapters
          })
        });
      } catch (_) {}
    }
    if (!response.ok) {
      try {
        response = await fetch(`${PROD_API_BASE_URL}/api/summarize`, {
          method: 'POST',
          body: JSON.stringify({
            videoUrl: data.url,
            settings: data.settings || {},
            extensionTranscript: data.transcript,
            extensionChapters: data.chapters
          })
        });
      } catch (_) {}
    }
    
    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }
    
    const apiResp = await response.json();
    if (apiResp.error) {
      throw new Error(apiResp.error);
    }
    const summaryData = apiResp.data || apiResp;
    console.log('✅ Summarization completed successfully');
    
    // Send result back to content script
    sendResponse({
      success: true,
      data: summaryData
    });
    
    // Notify popup if open
    try {
      chrome.runtime.sendMessage({
        type: 'summaryComplete',
        data: summaryData
      });
    } catch (e) {
      // Popup might not be open, that's fine
    }
    
  } catch (error) {
    console.error('❌ Summarization error:', error);
    
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

// Check API status
async function checkApiStatus(sendResponse) {
  try {
    const base = await resolveApiBaseUrl();
    const response = await fetch(`${base}/api/health`, {
      method: 'GET',
      timeout: 5000
    });
    
    sendResponse({
      success: response.ok,
      status: response.status
    });
  } catch (error) {
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

// Handle tab updates to reinject content script if needed
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  // Only act on YouTube watch pages that have finished loading
  if (changeInfo.status === 'complete' && 
      tab.url && 
      tab.url.includes('youtube.com/watch')) {
    
    console.log('📺 YouTube video page loaded, ensuring content script is active');
    
    // Try to ping the content script
    chrome.tabs.sendMessage(tabId, {action: 'ping'}, function(response) {
      if (chrome.runtime.lastError) {
        console.log('🔄 Content script not responding, might need manual refresh');
      }
    });
  }
});

// Context menu is created during onInstalled; ensure we don't double-create at runtime

chrome.contextMenus.onClicked.addListener(function(info, tab) {
  if (info.menuItemId === 'summarizeVideo') {
    try {
      chrome.tabs.sendMessage(tab.id, { action: 'startSummarization' }, () => {
        if (chrome.runtime.lastError) {
          // Try to inject by nudging the page to reload
          try { chrome.tabs.reload(tab.id); } catch (_) {}
        }
      });
    } catch (_) {}
  }
});