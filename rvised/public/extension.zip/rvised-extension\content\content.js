// Content script for YouTube pages
console.log('🎥 Rvised content script loaded on YouTube');

let rvisedOverlay = null;
let isProcessing = false;

// Production API endpoint (our deployed Vercel app) - UPDATED!
const PROD_API_BASE_URL = 'https://rvised.vercel.app';

async function fetchWithTimeout(url, options = {}, timeoutMs = 1500) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(id);
  }
}

// Fetch with exponential backoff for 429 errors  
async function fetchWithRetry(url, options = {}, maxRetries = 5, baseDelay = 2000) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      if (attempt > 0) {
        const delay = baseDelay * Math.pow(2, attempt - 1); // Exponential backoff: 2s, 4s, 8s, 16s
        console.log(`⏳ Rate limited, waiting ${delay}ms before retry ${attempt + 1}/${maxRetries}...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
      
      const response = await fetch(url, options);
      
      if (response.status === 429) {
        console.warn(`🚫 429 Too Many Requests for ${url.substring(0, 50)}...`);
        if (attempt === maxRetries - 1) {
          throw new Error(`Rate limited after ${maxRetries} attempts. Please wait a few minutes.`);
        }
        continue; // Retry
      }
      
      // Also retry on 503 Service Unavailable
      if (response.status === 503) {
        console.warn(`⚠️ 503 Service Unavailable for ${url.substring(0, 50)}...`);
        if (attempt === maxRetries - 1) {
          throw new Error(`Service unavailable after ${maxRetries} attempts`);
        }
        continue; // Retry
      }
      
      return response;
    } catch (error) {
      if (attempt === maxRetries - 1) throw error;
      console.log(`⚠️ Attempt ${attempt + 1} failed:`, error.message);
    }
  }
}

async function resolveApiBaseUrl() {
  try {
    const resp = await new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ action: 'getResolvedBase' }, (res) => resolve(res));
      } catch (e) { resolve(null) }
    });
    if (resp && resp.base) return resp.base;
  } catch (_) {}
  const candidates = ['http://localhost:3000', 'https://localhost:3000', PROD_API_BASE_URL];
  for (const base of candidates) {
    try {
      const r = await fetchWithTimeout(`${base}/api/health`, { method: 'GET' }, 1200);
      if (r.ok) return base;
    } catch (_) {}
  }
  return PROD_API_BASE_URL;
}

// Global probe transcript store and listener (consumes page-probe messages)
let __RVISED_PROBE_TEXT = null;
function __rvisedBuildFromEvents(events) {
  try {
    let out = '';
    let currentTime = 0;
    events.forEach(ev => {
      if (ev && typeof ev === 'object') {
        if (ev.tStartMs !== undefined) currentTime = Math.floor(ev.tStartMs / 1000);
        if (ev.segs) {
          const m = Math.floor(currentTime / 60).toString().padStart(2, '0');
          const s = (currentTime % 60).toString().padStart(2, '0');
          const ts = `${m}:${s}`;
          const text = ev.segs.map(seg => seg.utf8).join('').trim();
          if (text) out += `[${ts}] ${text} `;
        }
      }
    });
    return out.trim();
  } catch (_) { return null; }
}

window.addEventListener('message', (ev) => {
  try {
    const data = ev?.data;
    if (!data || typeof data !== 'object') return;
    if (data.type === 'RVISED_TIMEDTEXT' && data.payload?.json?.events) {
      const txt = __rvisedBuildFromEvents(data.payload.json.events);
      if (txt && txt.length > 20) __RVISED_PROBE_TEXT = txt;
    }
    if (data.type === 'RVISED_CAPTION_TRACKS' && Array.isArray(data.payload?.tracks)) {
      const tracks = data.payload.tracks;
      const englishTrack = tracks.find(t => t.languageCode?.startsWith('en')) || tracks[0];
      if (englishTrack?.baseUrl) {
        let trackUrl = englishTrack.baseUrl.replace(/\\u0026/g, '&');
        if (!trackUrl.includes('fmt=')) trackUrl += '&fmt=json3';
        fetchWithRetry(trackUrl).then(r => r.json()).then(json => {
          const txt = __rvisedBuildFromEvents(json?.events || []);
          if (txt && txt.length > 20) __RVISED_PROBE_TEXT = txt;
        }).catch((e) => {
          console.log('Failed to fetch caption track:', e.message);
        });
      }
    }
  } catch (_) {}
});

// Extract transcript directly from ytInitialPlayerResponse (XML baseUrl) or player API
async function extractTranscriptFromYouTube() {
  try {
    console.log('🔍 Extracting transcript from YouTube page data...');
    const scripts = document.querySelectorAll('script');
    let playerResponse = null;

    for (const script of scripts) {
      const text = script.textContent || '';
      if (text.includes('ytInitialPlayerResponse')) {
        const match = text.match(/ytInitialPlayerResponse\s*=\s*(\{[\s\S]*?\});/);
        if (match) {
          try {
            playerResponse = JSON.parse(match[1]);
            break;
          } catch (_) {}
        }
      }
    }

    // Fallback: ask the player element
    if (!playerResponse) {
      const player = document.getElementById('movie_player');
      if (player && typeof player.getPlayerResponse === 'function') {
        try { playerResponse = player.getPlayerResponse(); } catch (_) {}
      }
    }

    const tracks = playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    if (!Array.isArray(tracks) || tracks.length === 0) {
      throw new Error('No captions available in player response');
    }

    const pick = tracks.find(t => t.languageCode?.startsWith('en')) || tracks[0];
    let baseUrl = pick?.baseUrl;
    if (!baseUrl) throw new Error('No caption baseUrl');
    baseUrl = baseUrl.replace(/\\u0026/g, '&');

    // Prefer raw XML first (no fmt), then try json3, then vtt
    async function parseXml(xmlText) {
      const parser = new DOMParser();
      const xml = parser.parseFromString(xmlText, 'text/xml');
      const nodes = Array.from(xml.getElementsByTagName('text'));
      if (!nodes.length) return null;
      let out = '';
      for (const node of nodes) {
        const start = parseFloat(node.getAttribute('start') || '0');
        const m = Math.floor(start / 60).toString().padStart(2, '0');
        const s = Math.floor(start % 60).toString().padStart(2, '0');
        const ts = `${m}:${s}`;
        const raw = (node.textContent || '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\n/g, ' ').trim();
        if (raw) out += `[${ts}] ${raw} `;
      }
      return out.trim();
    }

    // Try XML with exponential backoff retry
    try {
      const xmlResp = await fetchWithRetry(baseUrl, { credentials: 'include', mode: 'cors' }, 5, 2000);
      if (xmlResp.ok) {
        const xmlText = await xmlResp.text();
        const text = await parseXml(xmlText);
        if (text && text.length > 20) return text;
      }
    } catch (e) {
      console.log('XML fetch failed:', e.message);
    }

    // Try json3 with exponential backoff retry
    try {
      const jsonUrl = baseUrl.includes('fmt=') ? baseUrl : `${baseUrl}&fmt=json3`;
      const jsonResp = await fetchWithRetry(jsonUrl, { credentials: 'include', mode: 'cors' }, 5, 2000);
      if (jsonResp.ok) {
        const j = await jsonResp.json();
        if (Array.isArray(j?.events)) {
          const txt = __rvisedBuildFromEvents(j.events);
          if (txt && txt.length > 20) return txt;
        }
      }
    } catch (e) {
      console.log('JSON3 fetch failed:', e.message);
    }

    // Try VTT with exponential backoff retry
    try {
      const vttResp = await fetchWithRetry(`${baseUrl}&fmt=vtt`, { credentials: 'include', mode: 'cors' }, 5, 2000);
      if (vttResp.ok) {
        const vtt = await vttResp.text();
        const lines = vtt.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('WEBVTT') && !/^\d+$/.test(l) && !/^\d{2}:\d{2}:\d{2}\.\d{3}/.test(l));
        const text = lines.join(' ');
        if (text.length > 20) return text;
      }
    } catch (e) {
      console.log('VTT fetch failed:', e.message);
    }

    // Ask page helper (with page cookies) to fetch the exact json3 URL and wait briefly for a response
    try {
      const jsonUrl = baseUrl.includes('fmt=') ? baseUrl : `${baseUrl}&fmt=json3`;
      const before = __RVISED_PROBE_TEXT;
      // Ensure helper is injected
      injectPageTimedtextFetch();
      window.postMessage({ type: 'RVISED_FETCH_CAPTION_URL', payload: { url: jsonUrl } }, '*');
      const got = await new Promise((resolve) => {
        let waited = 0;
        const step = 150;
        const timer = setInterval(() => {
          waited += step;
          if (typeof __RVISED_PROBE_TEXT === 'string' && __RVISED_PROBE_TEXT.length > 20 && __RVISED_PROBE_TEXT !== before) {
            clearInterval(timer);
            resolve(__RVISED_PROBE_TEXT);
          }
          if (waited >= 1500) { clearInterval(timer); resolve(null); }
        }, step);
      });
      if (got && got.length > 20) return got;
    } catch (_) {}

    // As a last in-frame resort, scrape the open transcript panel if user has it open
    try {
      const segments = document.querySelectorAll('ytd-transcript-segment-renderer');
      if (segments && segments.length) {
        let out = '';
        segments.forEach(seg => {
          const timeEl = seg.querySelector('.segment-start-offset, .segment-timestamp, .cue-group-start-offset');
          const textEl = seg.querySelector('.segment-text, yt-formatted-string[aria-label]');
          const time = (timeEl?.textContent || '').trim();
          const txt = (textEl?.textContent || '').trim();
          if (txt) out += (time ? `[${time}] ` : '') + `${txt} `;
        });
        const cleaned = out.trim();
        if (cleaned.length > 20) return cleaned;
      }
    } catch (_) {}

    throw new Error('Caption fetch failed');
  } catch (err) {
    console.log('Transcript extraction (ytInitialPlayerResponse) failed:', err);
    return null;
  }
}

// Extract video ID from current YouTube URL
function getVideoId() {
  const urlParams = new URLSearchParams(window.location.search);
  const vParam = urlParams.get('v');
  if (vParam) return vParam;
  // Support embed and shorts URLs
  const pathMatch = (window.location.pathname.match(/\/embed\/([^/?#]+)/) || window.location.pathname.match(/\/shorts\/([^/?#]+)/));
  return pathMatch ? pathMatch[1] : null;
}

// Extract YouTube chapters from page data
function extractChaptersFromPage() {
  try {
    console.log('🔍 Extracting YouTube chapters from page...');
    
    // Method 1: Look for chapters in page scripts (MORE AGGRESSIVE)
    const scripts = document.querySelectorAll('script');
    console.log(`📖 Searching ${scripts.length} scripts for chapter data...`);
    
    for (const script of scripts) {
      const scriptContent = script.textContent;
      
      // Look for various chapter patterns
      const patterns = [
        /"chapters":\s*(\[[\s\S]*?\])/,
        /"macroMarkers":\s*(\[[\s\S]*?\])/,
        /"segments":\s*(\[[\s\S]*?\])/,
        /chapters\s*=\s*(\[[\s\S]*?\])/,
        /macroMarkers\s*=\s*(\[[\s\S]*?\])/
      ];
      
      for (const pattern of patterns) {
        const match = scriptContent.match(pattern);
        if (match) {
          try {
            const data = JSON.parse(match[1]);
            console.log('📖 Found chapter data with pattern:', pattern, data);
            
            if (data.length > 0) {
              if (data[0].timeRangeStartMillis) {
                return parseChapterData(data);
              } else if (data[0].startTime) {
                return parseSimpleChapterData(data);
              }
            }
          } catch (e) {
            console.log('❌ Failed to parse chapter data:', e);
          }
        }
      }
    }
    
    // Method 2: Look for chapters in DOM elements
    const chapterElements = document.querySelectorAll('[data-segment-time], .ytp-chapter-title, .segment-timestamp');
    if (chapterElements.length > 0) {
      const chapters = [];
      chapterElements.forEach(el => {
        const timeAttr = el.getAttribute('data-segment-time') || el.getAttribute('data-start-time');
        const titleText = (el.querySelector('.segment-title')?.textContent || el.textContent || '').trim();
        if (timeAttr && titleText) {
          chapters.push({
            time: formatSeconds(parseInt(timeAttr)),
            description: titleText
          });
        }
      });
      if (chapters.length > 0) {
        console.log('📖 Extracted chapters from DOM:', chapters);
        return chapters;
      }
    }
    
    console.log('❌ No chapters found in page data');
    return null;
  } catch (error) {
    console.log('❌ Error extracting chapters:', error);
    return null;
  }
}

// Parse YouTube chapter data format
function parseChapterData(chapters) {
  return chapters.map(chapter => ({
    time: formatSeconds(chapter.timeRangeStartMillis / 1000),
    description: chapter.title || 'Chapter'
  }));
}

// Parse YouTube macro markers format  
function parseMacroMarkers(markers) {
  return markers.map(marker => ({
    time: formatSeconds(marker.timeRangeStartMillis / 1000),
    description: marker.title || 'Section'
  }));
}

// Parse simple chapter data format
function parseSimpleChapterData(chapters) {
  return chapters.map(chapter => ({
    time: formatSeconds(chapter.startTime || chapter.time || 0),
    description: chapter.title || chapter.name || 'Chapter'
  }));
}

// Format seconds to mm:ss
function formatSeconds(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Inject a page-context script to proactively fetch timedtext and post it back
function injectPageTimedtextFetch() {
  try {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('content/page-fetch-timedtext.js');
    (document.head || document.documentElement).appendChild(s);
    s.onload = () => s.remove();
  } catch (_) {}
}

// Extract transcript WITH TIMESTAMPS directly from YouTube's player data  
function extractTranscriptFromPage() {
  return new Promise((resolve) => {
    try {
      // Try direct, in-frame extraction first (Eightify-style)
      extractTranscriptFromYouTube().then((direct) => {
        if (direct && direct.length > 20) {
          return resolve(direct);
        }
        // If probe already captured data, use it immediately or after a brief wait
        if (typeof __RVISED_PROBE_TEXT === 'string' && __RVISED_PROBE_TEXT.length > 20) {
          return resolve(__RVISED_PROBE_TEXT);
        }
        // Proactively trigger timedtext fetch in page context and WAIT for it before scraping
        injectPageTimedtextFetch();
        setTimeout(() => {
          if (typeof __RVISED_PROBE_TEXT === 'string' && __RVISED_PROBE_TEXT.length > 20) {
            return resolve(__RVISED_PROBE_TEXT);
          }
          // Final fallback: ask our background to call server /api/transcript for us
          try {
            const vid = getVideoId();
            chrome.runtime.sendMessage({ action: 'fetchTranscriptServer', videoUrl: window.location.href, videoId: vid }, (resp) => {
              if (resp && resp.success && resp.transcript && resp.transcript.length > 20) {
                return resolve(resp.transcript);
              }
              return resolve(null);
            });
          } catch(_) { return resolve(null); }
        }, 1500);
      });
      return;
      // If probe already captured data, use it immediately or after a brief wait
      if (typeof __RVISED_PROBE_TEXT === 'string' && __RVISED_PROBE_TEXT.length > 20) {
        return resolve(__RVISED_PROBE_TEXT);
      }
      // Proactively trigger timedtext fetch in page context and WAIT for it before scraping
      injectPageTimedtextFetch();
      setTimeout(() => {
        if (typeof __RVISED_PROBE_TEXT === 'string' && __RVISED_PROBE_TEXT.length > 20) {
          return resolve(__RVISED_PROBE_TEXT);
        }
        // Final fallback: ask our background to call server /api/transcript for us
        try {
          const vid = getVideoId();
          chrome.runtime.sendMessage({ action: 'fetchTranscriptServer', videoUrl: window.location.href, videoId: vid }, (resp) => {
            if (resp && resp.success && resp.transcript && resp.transcript.length > 20) {
              return resolve(resp.transcript);
            }
            return resolve(null);
          });
        } catch(_) { return resolve(null); }
      }, 1500);
      return;
      // If probe has already captured timedtext, use it immediately
      if (typeof __RVISED_PROBE_TEXT === 'string' && __RVISED_PROBE_TEXT.length > 20) {
        return resolve(__RVISED_PROBE_TEXT);
      }
      // Give the probe a small window to capture initial timedtext requests
      setTimeout(() => {
        if (typeof __RVISED_PROBE_TEXT === 'string' && __RVISED_PROBE_TEXT.length > 20) {
          return resolve(__RVISED_PROBE_TEXT);
        }
      }, 600);
      // Method 1: Try to find transcript data in page
      const scripts = document.querySelectorAll('script');
      let transcriptData = null;
      let innertubeJson = null;
      
      for (const script of scripts) {
        if (script.textContent.includes('captionTracks')) {
          const match = script.textContent.match(/"captionTracks":\s*(\[[^\]]+\])/);
          if (match) {
            try {
              transcriptData = JSON.parse(match[1]);
              break;
            } catch (e) {
              console.log('Failed to parse captionTracks:', e);
            }
          }
        }
        // Backup: parse ytInitialPlayerResponse or ytInitialData blobs for captions
        if (!transcriptData && (script.textContent.includes('ytInitialPlayerResponse') || script.textContent.includes('ytInitialData'))) {
          const prMatch = script.textContent.match(/ytInitialPlayerResponse\s*=\s*(\{[\s\S]*?\});/);
          if (prMatch) {
            try {
              const pr = JSON.parse(prMatch[1]);
              const tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
              if (Array.isArray(tracks) && tracks.length) {
                transcriptData = tracks;
                break;
              }
            } catch (e) {}
          }
          const dataMatch = script.textContent.match(/ytInitialData\s*=\s*(\{[\s\S]*?\});/);
          if (dataMatch) {
            try { innertubeJson = JSON.parse(dataMatch[1]); } catch (e) {}
          }
        }
      }
      
      if (transcriptData && transcriptData.length > 0) {
        // Found transcript data, fetch the actual transcript WITH TIMESTAMPS
        const englishTrack = transcriptData.find(track => 
          track.languageCode && track.languageCode.startsWith('en')
        ) || transcriptData[0];
        
        if (englishTrack && englishTrack.baseUrl) {
          let trackUrl = englishTrack.baseUrl.replace(/\\u0026/g, '&');
          // Request JSON format to get timestamps
          if (!trackUrl.includes('fmt=')) {
            trackUrl += '&fmt=json3';
          }
          
          fetch(trackUrl)
            .then(response => response.json())
            .then(json => {
              if (json?.events) {
                // Extract both text and timing information
                let transcriptWithTimestamps = '';
                let currentTime = 0;
                
                json.events.forEach(event => {
                  if (event.tStartMs !== undefined) {
                    currentTime = Math.floor(event.tStartMs / 1000);
                  }
                  if (event.segs) {
                    const minutes = Math.floor(currentTime / 60);
                    const seconds = currentTime % 60;
                    const timeStamp = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                    
                    const text = event.segs.map(seg => seg.utf8).join('').trim();
                    if (text) {
                      transcriptWithTimestamps += `[${timeStamp}] ${text} `;
                    }
                  }
                });
                
                console.log('✅ Extracted transcript with timestamps');
                resolve(transcriptWithTimestamps.trim());
              } else {
                // Fallback to VTT if JSON doesn't work
                let vttUrl = englishTrack.baseUrl.replace(/\\u0026/g, '&') + '&fmt=vtt';
                return fetch(vttUrl).then(r => r.text()).then(vtt => {
                  const lines = vtt
                    .split('\n')
                    .map(line => line.trim())
                    .filter(line => 
                      line && 
                      !line.startsWith('WEBVTT') && 
                      !/^\d+$/.test(line) && 
                      !/^\d{2}:\d{2}:\d{2}\.\d{3}/.test(line)
                    );
                  resolve(lines.join(' '));
                });
              }
            })
            .catch(err => {
              console.log('Failed to fetch JSON transcript, trying VTT fallback:', err);
              // Fallback to VTT format
              let vttUrl = englishTrack.baseUrl.replace(/\\u0026/g, '&') + '&fmt=vtt';
              fetch(vttUrl)
                .then(response => response.text())
                .then(vtt => {
                  const lines = vtt
                    .split('\n')
                    .map(line => line.trim())
                    .filter(line => 
                      line && 
                      !line.startsWith('WEBVTT') && 
                      !/^\d+$/.test(line) && 
                      !/^\d{2}:\d{2}:\d{2}\.\d{3}/.test(line)
                    );
                  resolve(lines.join(' '));
                })
                .catch(() => resolve(null));
            });
        } else {
          resolve(null);
        }
      } else {
        // Last resort: attempt to parse transcript-like text from rendered DOM
        const possibleNodes = document.querySelectorAll('.ytp-caption-segment, .caption-window, [class*="caption" i]');
        if (possibleNodes && possibleNodes.length) {
          const text = Array.from(possibleNodes).map(n => n.textContent?.trim() || '').filter(Boolean).join(' ');
          if (text && text.length > 50) {
            return resolve(text);
          }
        }
        // Timed-text by videoId (language listing)
        const vid = getVideoId();
        if (!vid) return resolve(null);
        fetch(`https://video.google.com/timedtext?type=list&v=${vid}`)
          .then(r => r.text())
          .then(xml => {
            try {
              const langs = Array.from(xml.matchAll(/<track[^>]*lang_code="([^"]+)"[^>]*>/g)).map(m => m[1]);
              const pick = langs.find(l => l.startsWith('en')) || langs[0];
              if (!pick) return resolve(null);
              return fetch(`https://video.google.com/timedtext?v=${vid}&lang=${pick}&fmt=json3`)
                .then(r => r.ok ? r.json() : null)
                .then(json => {
                  if (!json || !Array.isArray(json.events)) return resolve(null);
                  let out = '';
                  let currentTime = 0;
                  json.events.forEach(ev => {
                    if (ev.tStartMs !== undefined) currentTime = Math.floor(ev.tStartMs / 1000);
                    if (ev.segs) {
                      const m = Math.floor(currentTime / 60).toString().padStart(2, '0');
                      const s = (currentTime % 60).toString().padStart(2, '0');
                      const ts = `${m}:${s}`;
                      const text = ev.segs.map(seg => seg.utf8).join('').trim();
                      if (text) out += `[${ts}] ${text} `;
                    }
                  });
                  resolve(out.trim() || null);
                });
            } catch {
              resolve(null);
            }
          })
          .catch(() => resolve(null));
      }
    } catch (error) {
      console.log('Transcript extraction error:', error);
      resolve(null);
    }
  });
}

// Create and inject the Rvised overlay
function createRvisedOverlay() {
  if (rvisedOverlay) {
    rvisedOverlay.remove();
  }
  
  rvisedOverlay = document.createElement('div');
  rvisedOverlay.id = 'rvised-overlay';
  rvisedOverlay.innerHTML = `
    <div class="rvised-container">
      <div class="rvised-header">
        <span class="rvised-logo">📚 Rvised</span>
        <button class="rvised-close" onclick="this.closest('#rvised-overlay').style.display='none'">×</button>
      </div>
      
      <div class="rvised-content">
        <div class="rvised-settings">
          <div class="setting-group">
            <label for="learningMode">Learning Mode:</label>
            <select id="learningMode" name="learningMode" autocomplete="off">
              <option value="Student">🎓 Student</option>
              <option value="Build" selected>🔧 Build</option>
              <option value="Understand">🧠 Understand</option>
            </select>
          </div>
          
          <div class="setting-group">
            <label for="summaryDepth">Summary Depth:</label>
            <select id="summaryDepth" name="summaryDepth" autocomplete="off">
              <option value="quick">⚡ Quick</option>
              <option value="standard" selected>📋 Standard</option>
              <option value="deep">🔍 Deep</option>
            </select>
          </div>
          
          <div class="toggle-group">
            <label for="includeEmojis"><input type="checkbox" id="includeEmojis" name="includeEmojis" checked> Include Emojis</label>
            <label for="includeQuiz"><input type="checkbox" id="includeQuiz" name="includeQuiz" checked> Quiz Questions</label>
            <label for="includeTimestamps"><input type="checkbox" id="includeTimestamps" name="includeTimestamps" checked> Timestamps</label>
          </div>
        </div>
        
        <button id="summarizeBtn" name="summarizeBtn" class="rvised-button">
          ✨ Generate Summary
        </button>
        
        <div id="summaryResult" class="summary-result" style="display: none;">
          <!-- Summary will be inserted here -->
        </div>
        
        <div id="loadingState" class="loading-state" style="display: none;">
          <div class="spinner"></div>
          <p>Analyzing video and generating summary...</p>
        </div>
      </div>
    </div>
  `;
  
  document.body.appendChild(rvisedOverlay);
  
  // Add event listeners
  const summarizeBtnEl = document.getElementById('summarizeBtn');
  if (summarizeBtnEl) summarizeBtnEl.addEventListener('click', handleSummarize);
}

// Handle summarization process
async function handleSummarize() {
  if (isProcessing) return;
  
  const videoId = getVideoId();
  if (!videoId) {
    alert('No video ID found. Please make sure you\'re on a YouTube video page.');
    return;
  }
  
  isProcessing = true;
  const loadingState = document.getElementById('loadingState');
  const summaryResult = document.getElementById('summaryResult');
  const summarizeBtn = document.getElementById('summarizeBtn');
  
  // Show loading state
  if (loadingState) loadingState.style.display = 'block';
  if (summaryResult) summaryResult.style.display = 'none';
  if (summarizeBtn) {
    summarizeBtn.disabled = true;
    summarizeBtn.textContent = 'Processing...';
  }
  
  try {
    // Get settings from UI
    const settings = {
      learningMode: document.getElementById('learningMode').value,
      summaryDepth: document.getElementById('summaryDepth').value,
      includeEmojis: document.getElementById('includeEmojis').checked,
      includeQuiz: document.getElementById('includeQuiz').checked,
      includeTimestamps: document.getElementById('includeTimestamps').checked
    };
    
    // DIRECT TRANSCRIPT EXTRACTION WITH 429 BYPASS
    console.log('🎯 EXTRACTING TRANSCRIPT WITH 429 BYPASS...');
    let localTranscript = null;
    let transcriptPresent = false;
    
    // First, try DOM extraction to bypass 429
    try {
      console.log('🔄 Attempting DOM extraction (no HTTP requests)...');
      
      // Method 1: Try opening transcript panel
      const moreActionsBtn = document.querySelector('button[aria-label*="More actions"]');
      if (moreActionsBtn) {
        moreActionsBtn.click();
        await new Promise(r => setTimeout(r, 500));
        
        const transcriptOption = Array.from(document.querySelectorAll('yt-formatted-string'))
          .find(el => el.textContent?.toLowerCase().includes('transcript'));
        
        if (transcriptOption) {
          transcriptOption.click();
          await new Promise(r => setTimeout(r, 1500));
          
          const segments = document.querySelectorAll('ytd-transcript-segment-renderer');
          if (segments.length > 0) {
            localTranscript = Array.from(segments)
              .map(seg => seg.querySelector('.segment-text')?.textContent?.trim())
              .filter(text => text)
              .join(' ');
            
            if (localTranscript && localTranscript.length > 100) {
              transcriptPresent = true;
              console.log('✅ BYPASSED 429! Extracted from transcript panel:', localTranscript.length, 'chars');
            }
          }
        }
      }
    } catch (e) {
      console.log('DOM extraction attempt failed:', e.message);
    }
    
    // If DOM extraction failed, try HTTP method
    if (!localTranscript) {
      try {
        console.log('🔄 Attempting HTTP extraction...');
        // Get ytInitialPlayerResponse from page
        const scripts = document.querySelectorAll('script');
        for (const script of scripts) {
          const content = script.textContent || '';
          if (content.includes('ytInitialPlayerResponse')) {
            const match = content.match(/ytInitialPlayerResponse\s*=\s*({.+?});/);
            if (match) {
              const playerResponse = JSON.parse(match[1]);
              const tracks = playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
              
              if (!tracks || tracks.length === 0) {
                console.log('⚠️ This video has no caption tracks available');
                break;
              }
              
              console.log(`📝 Found ${tracks.length} caption track(s)`);
              const track = tracks.find(t => t.languageCode?.startsWith('en')) || tracks[0];
              
              if (track?.baseUrl) {
                let url = track.baseUrl.replace(/\\u0026/g, '&');
                console.log('📥 Fetching captions from:', url.substring(0, 80) + '...');
                
                try {
                  const response = await fetch(url);
                  
                  if (response.status === 429) {
                    console.log('⚠️ Rate limited (429) - YouTube is blocking requests');
                    console.log('💡 TIP: Try using incognito mode or wait 5-10 minutes');
                    // Store rate limit status
                    sessionStorage.setItem('rvised_rate_limited', 'true');
                    sessionStorage.setItem('rvised_rate_limit_time', Date.now());
                    break;
                  }
                  
                  if (response.ok) {
                    const text = await response.text();
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(text, 'text/xml');
                    const textNodes = doc.querySelectorAll('text');
                    
                    if (textNodes.length > 0) {
                      localTranscript = Array.from(textNodes)
                        .map(node => {
                          let content = node.textContent || '';
                          return content.replace(/&amp;/g, '&').replace(/&#39;/g, "'").trim();
                        })
                        .filter(text => text.length > 0)
                        .join(' ');
                      
                      if (localTranscript.length > 100) {
                        transcriptPresent = true;
                        console.log('✅ INLINE EXTRACTION SUCCESS:', localTranscript.length, 'chars');
                      }
                    }
                  }
                } catch (fetchError) {
                  console.log('⚠️ Caption fetch failed:', fetchError.message);
                }
              }
              break;
            }
          }
        }
    } catch (e) {
      console.log('Inline extraction error:', e.message);
    }
    
    if (!localTranscript) {
      console.log('❌ NO TRANSCRIPT AVAILABLE - Will use description fallback');
      
      // Check if rate limited
      const wasRateLimited = sessionStorage.getItem('rvised_rate_limited');
      if (wasRateLimited === 'true') {
        const rateLimitTime = sessionStorage.getItem('rvised_rate_limit_time');
        const minutesAgo = Math.floor((Date.now() - parseInt(rateLimitTime)) / 60000);
        
        console.log(`⚠️ YouTube rate limiting detected ${minutesAgo} minutes ago`);
        console.log('💡 Solutions:');
        console.log('   1. Use Chrome Incognito mode');
        console.log('   2. Wait 5-10 minutes');
        console.log('   3. Try a different browser');
        console.log('   4. Clear YouTube cookies');
      }
    }
    
    // Also try to extract chapters
    let localChapters = null;
    try {
      localChapters = extractChaptersFromPage();
      if (localChapters && localChapters.length > 0) {
        console.log('✅ Extracted', localChapters.length, 'chapters locally');
      }
    } catch (error) {
      console.log('⚠️ Chapter extraction failed:', error.message);
    }
    
    // Direct fetch from content script with retry logic
    const API_BASE_URL = await resolveApiBaseUrl();
    let summaryData = null;
    let response = await fetchWithRetry(`${API_BASE_URL}/api/summarize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        videoUrl: window.location.href,
        settings: settings,
        extensionTranscript: localTranscript,
        extensionChapters: localChapters
      })
    }, 3, 2000); // 3 retries with 2 second base delay

    if (!response.ok || response.type === 'opaque') {
      try {
        response = await fetchWithRetry(`http://localhost:3000/api/summarize`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            videoUrl: window.location.href,
            settings,
            extensionTranscript: localTranscript,
            extensionChapters: localChapters
          })
        }, 2, 1000); // Fewer retries for fallback
      } catch (_) {}
    }

    if (!response || !response.ok) {
      const status = response ? response.status : 'unknown';
      throw new Error(`API request failed: ${status}`);
    }
    const apiResp = await response.json();
    if (apiResp.error) {
      throw new Error(apiResp.error);
    }
    summaryData = apiResp.data || apiResp;
    
    // FORCE TIMESTAMPS: If timestamps are enabled but not provided, create fallback
    const timestampsEnabled = document.getElementById('includeTimestamps')?.checked;
    if (timestampsEnabled && (!summaryData.timestampedSections || summaryData.timestampedSections.length === 0)) {
      console.log('⚠️ API did not provide timestamps, creating fallback...');
      
      // Try to use the chapters we extracted locally
      if (localChapters && localChapters.length > 0) {
        console.log('🎯 Using locally extracted chapters as fallback');
        summaryData.timestampedSections = localChapters;
      } else {
        console.log('📝 Creating basic fallback timestamps');
        summaryData.timestampedSections = [
          { time: "00:00", description: "Introduction" },
          { time: "02:00", description: "Main content begins" },
          { time: "05:00", description: "Key concepts" },
          { time: "08:00", description: "Advanced topics" },
          { time: "12:00", description: "Conclusion" }
        ];
      }
    }
    
    // Display the summary
    displaySummary(summaryData);
    // Store the latest data for Save action if needed
    window.__RVISED_LAST_SUMMARY__ = { data: summaryData, url: window.location.href };
    
  } catch (error) {
    console.error('Summarization error:', error);
    
    // Provide more specific error messages
    let errorMessage = error.message;
    let helpText = 'Please try again or check your connection.';
    
    if (error.message.includes('429') || error.message.includes('Rate limited')) {
      errorMessage = 'YouTube rate limit reached';
      helpText = 'Too many requests. Please wait a few minutes before trying again.';
    } else if (error.message.includes('transcript')) {
      errorMessage = 'Unable to extract transcript';
      helpText = 'The video may have restricted captions or be unavailable. Try a different video.';
    } else if (error.message.includes('API request failed')) {
      errorMessage = 'Connection error';
      helpText = 'Could not connect to the summarization service. Please check your internet connection.';
    }
    
    if (summaryResult) {
      summaryResult.innerHTML = `
        <div class="error">
          <h3>❌ ${errorMessage}</h3>
          <p>${helpText}</p>
          <button onclick="location.reload()" style="margin-top: 10px; padding: 8px 16px; background: #ff0000; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Refresh Page
          </button>
        </div>
      `;
      summaryResult.style.display = 'block';
    }
  } finally {
    isProcessing = false;
    if (loadingState) loadingState.style.display = 'none';
    if (summarizeBtn) {
      summarizeBtn.disabled = false;
      summarizeBtn.textContent = '✨ Generate Summary';
    }
  }
}

// Display summary in the overlay
function displaySummary(data) {
  const summaryResult = document.getElementById('summaryResult');
  
  const infoLine = [data.channel, data.duration].filter(Boolean).join(' • ');
  const sourceLabel = (data.contentSource === 'extension-transcript' || data.contentSource === 'transcript') ? 'Transcript' : (data.contentSource === 'title-description' ? 'Title & Description' : 'Unknown');
  let html = `
    <div class="summary-content">
      <div class="summary-header">
        <h2>📚 ${data.title || 'Video Summary'}</h2>
        <p class="video-info">${infoLine}${infoLine ? ' • ' : ''}<span style="background:#eef2ff;color:#3730a3;padding:2px 6px;border-radius:6px;font-size:12px;">Source: ${sourceLabel}</span></p>
      </div>
      
      <div class="main-takeaway">
        <h3>🎯 Main Takeaway</h3>
        <p>${data.mainTakeaway}</p>
      </div>
      
      <div class="summary-text">
        <h3>📝 Summary</h3>
        <div>${data.summary}</div>
      </div>
  `;
  
  if (data.techStack && data.techStack.length > 0) {
    html += `
      <div class="tech-stack">
        <h3>🛠️ Tech Stack</h3>
        <div class="tech-tags">
          ${data.techStack.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
        </div>
      </div>
    `;
  }
  
  if (data.keyInsights && data.keyInsights.length > 0) {
    html += `
      <div class="key-insights">
        <h3>💡 Key Insights</h3>
        <ul>
          ${data.keyInsights.map(insight => `<li>${insight}</li>`).join('')}
        </ul>
      </div>
    `;
  }
  
  if (data.actionItems && data.actionItems.length > 0) {
    html += `
      <div class="action-items">
        <h3>⚡ Action Items</h3>
        <ul>
          ${data.actionItems.map(item => `<li>${item}</li>`).join('')}
        </ul>
      </div>
    `;
  }

  // COMPREHENSIVE TIMESTAMP DEBUGGING & DISPLAY
  const timestampsEnabled = document.getElementById('includeTimestamps')?.checked;
  console.log('🔍 FRONTEND TIMESTAMP DEBUG:');
  console.log('- Timestamps enabled:', timestampsEnabled);
  console.log('- Data received:', data);
  console.log('- timestampedSections:', data.timestampedSections);
  console.log('- Type of timestampedSections:', typeof data.timestampedSections);
  console.log('- Is array:', Array.isArray(data.timestampedSections));
  
  if (timestampsEnabled) {
    const timestamps = data.timestampedSections || [];
    console.log('- Processed timestamps:', timestamps);
    console.log('- Timestamps length:', timestamps.length);
    
    html += `
      <div class="timestamped-sections">
        <h3>📍 Timestamped Sections</h3>
        <ul>
          ${timestamps.length > 0 
            ? timestamps.map(section => {
                console.log('- Processing section:', section);
                return `<li><strong>[${section.time || '00:00'}]</strong> ${section.description || 'No description'}</li>`;
              }).join('') 
            : '<li><strong>[00:00]</strong> Timestamps not available for this video</li>'
          }
        </ul>
      </div>
    `;
    console.log(`✅ FRONTEND: Displayed ${timestamps.length} timestamp sections`);
  } else {
    console.log('❌ FRONTEND: Timestamps disabled by user');
  }

  // CODE SNIPPETS: REMOVED - Feature eliminated for simplicity

  // FRONTEND VALIDATION - Always show quiz section if enabled
  const quizEnabled = document.getElementById('includeQuiz')?.checked;
  if (quizEnabled) {
    const quiz = data.quiz || [];
    html += `
      <div class="quiz-section">
        <h3>🧪 Test Your Knowledge</h3>
        ${quiz.length > 0 
          ? quiz.map(q => `
            <div class="quiz-item">
              <p><strong>Q:</strong> ${q.question}</p>
              <p><em>A: ${q.answer}</em></p>
            </div>
          `).join('')
          : '<div class="quiz-item"><p><strong>Q:</strong> No quiz questions available for this video</p></div>'
        }
      </div>
    `;
    console.log(`✅ FRONTEND: Displayed ${quiz.length} quiz questions`);
  }

  
  html += `
      <div class="summary-actions">
        <button id="copySummaryBtn" class="action-btn">📋 Copy Summary</button>
        <button id="saveToProjectBtn" class="action-btn">💾 Save to Project</button>
        <a id="openDashboardBtn" href="#" class="action-btn">🎯 Open Dashboard</a>
      </div>
    </div>
  `;
  
  summaryResult.innerHTML = html;
  summaryResult.style.display = 'block';
  // Attach event listener for copy (avoid inline handlers due to isolated world)
  const copyBtn = document.getElementById('copySummaryBtn');
  if (copyBtn) {
    copyBtn.addEventListener('click', (evt) => copyToClipboard(evt));
  }
  const saveBtn = document.getElementById('saveToProjectBtn');
  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      try {
        await saveSummaryToProject(data);
        const API_BASE_URL = await resolveApiBaseUrl();
        window.open(`${API_BASE_URL}/dashboard`, '_blank');
      } catch (e) {
        alert('Failed to save to project.');
      }
    });
  }
  const openBtn = document.getElementById('openDashboardBtn');
  if (openBtn) {
    openBtn.addEventListener('click', async (evt) => {
      evt.preventDefault();
      const API_BASE_URL = await resolveApiBaseUrl();
      window.open(`${API_BASE_URL}/dashboard`, '_blank');
    });
  }
}

// Copy summary to clipboard
function copyToClipboard(evt) {
  const summaryContent = document.querySelector('.summary-content');
  if (summaryContent) {
    const text = summaryContent.innerText;
    navigator.clipboard.writeText(text).then(() => {
      const btn = evt?.target;
      if (btn && btn.textContent) {
        const originalText = btn.textContent;
        btn.textContent = '✅ Copied!';
        setTimeout(() => {
          btn.textContent = originalText;
        }, 2000);
      }
    });
  }
}

// Do not expose functions globally; handlers are attached programmatically

async function saveSummaryToProject(summaryData) {
  const payload = {
    projectName: 'My Library',
    videoUrl: window.location.href,
    data: summaryData
  };
  const API_BASE_URL = await resolveApiBaseUrl();
  // Try resolved base, then localhost fallbacks
  let resp = await fetch(`${API_BASE_URL}/api/projects`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    try {
      resp = await fetch('https://localhost:3000/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (_) {}
  }
  if (!resp.ok) {
    try {
      resp = await fetch('http://localhost:3000/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (_) {}
  }
  if (!resp.ok) throw new Error('Save failed');
  const json = await resp.json();
  if (!json.success) throw new Error(json.error || 'Save failed');
  return json.item;
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action === 'startSummarization') {
    if (!rvisedOverlay || rvisedOverlay.style.display === 'none') {
      createRvisedOverlay();
    }
    handleSummarize();
    sendResponse({success: true});
    return; 
  }
  if (message.action === 'ping') {
    sendResponse({ ok: true });
    return;
  }
});

// Initialize when page loads
function initializeRvised() {
  // Only run on YouTube watch pages
  const isWatch = /(^|\/)watch(\?|$)/.test(window.location.pathname + window.location.search);
  if (isWatch) {
    console.log('🎬 YouTube video page detected, initializing Rvised...');
    
    // Wait a bit for YouTube to load
    setTimeout(() => {
      createRvisedOverlay();
      
      // AUTO-POPUP: Automatically show the overlay and start summarizing
      const overlay = document.getElementById('rvised-overlay');
      if (overlay) {
        overlay.style.display = 'block';
        console.log('🚀 Auto-popup activated!');
        
        // Optional: Auto-start summarization after a short delay
        setTimeout(() => {
          const summarizeBtn = document.getElementById('rvised-summarize-btn');
          if (summarizeBtn && !summarizeBtn.disabled) {
            console.log('🤖 Auto-starting summarization...');
            summarizeBtn.click();
          }
        }, 1500);
      }
    }, 2000);
  }
}

// Initialize on page load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeRvised);
} else {
  initializeRvised();
}

// Handle YouTube's SPA navigation (guard against duplicate observers)
if (!window.__RVISED_NAV_OBSERVER) {
  window.__RVISED_NAV_OBSERVER = true;
  let lastUrl = location.href;
  const observer = new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(initializeRvised, 1000); // Delay to let YouTube load
    }
  });
  observer.observe(document.body || document.documentElement, { subtree: true, childList: true });
}